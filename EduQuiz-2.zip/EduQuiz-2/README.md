FINAL YEAR DJANGO PROJECT
Run:
pip install django
python manage.py migrate
python manage.py runserver