from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.shortcuts import render

def home(request):
    return render(request, 'home.html')
def login_view(r): return render(r,'login.html')
def signup(r): return render(r,'signup.html')
def logout_view(r): logout(r); return redirect('/login/')