from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),   # 👈 ROOT URL
    path('login/', views.login_view),
    path('signup/', views.signup),
    path('logout/', views.logout_view),
]
