from django.shortcuts import render
from django.contrib.auth.decorators import login_required
@login_required
def dashboard(r): return render(r,'dashboard.html')