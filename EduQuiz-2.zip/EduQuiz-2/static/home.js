function startQuiz() {
    alert("Quiz page will be connected soon!");
}